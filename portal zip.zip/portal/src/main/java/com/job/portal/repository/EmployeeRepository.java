package com.job.portal.repository;

public class EmployeeRepository {

}
